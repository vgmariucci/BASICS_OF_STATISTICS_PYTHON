#  Estatística descritiva básica para as idades dos personagens dos Simpsons

## Neste exmplo temos duas amostras organizadas em dois grupos:

---
Grupo 1:    Idade  

Mag     ->      1

Lisa    ->      8

Bart    ->      10

Marge    ->     38

Homer    ->     39

---
Grupo 2:    Idade  

Isabela   ->    8

Millhouse  ->   10 

Edna      ->    39

Moe       ->    45  

Skinner    ->  49
