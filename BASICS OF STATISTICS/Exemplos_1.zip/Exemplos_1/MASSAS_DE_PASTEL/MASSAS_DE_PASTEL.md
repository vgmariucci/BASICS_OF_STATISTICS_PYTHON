
# Example 2: Massas de Pastel

 Uma fábrica produz massa pronta para pasteis. Diariamente é medida a densidade da mistura das massas 
 em máquinas diferentes. Dadas as medições a seguir, calcule a média, mediana, desvio padrão e crie o 
 gráfico boxplot utilizando scripts em python.



# Mistura 1

Densidade (kg/L):     22.02      23.83     26.67      25.38      25.49      23.50      25.90     24.89

---

# Mistura 2

Densidade (kg/L):     21.49      22.67      24.62      24.18      22.78      22.56      24.46     23.79

---

# Mistura 3

Densidade (kg/L):     20.33      21.67      24.67      22.45      22.29      21.95      20.49     21.81    

---



---
